package com.plantdiseasedetector.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
